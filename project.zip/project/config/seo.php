<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'bet, bet365, betting, cricket, gambling, game, hyip, invest, ipl, live, lottery, online betting, online game, soccer, sports',
  'meta_description' => 'Prophecy - An Online Betting Platform',
  'social_title' => 'Prophecy - An Online Betting Platform',
  'social_description' => 'Prophecy - An Online Betting Platform',
);