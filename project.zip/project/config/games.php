<?php

return [
    "Globe" => '<i class="far fa-globe-americas" aria-hidden="true"></i>',
    "Cricket" => '<i class="far fa-cricket" aria-hidden="true"></i>',
    "Football" => '<i class="far fa-futbol" aria-hidden="true"></i>',
    "Table tennis" => '<i class="far fa-table-tennis" aria-hidden="true"></i>',
    "Baseball" => '<i class="far fa-baseball" aria-hidden="true"></i>',
    "Basketball" => '<i class="far fa-basketball-ball" aria-hidden="true"></i>',
    "Hockey" => '<i class="far fa-field-hockey" aria-hidden="true"></i>',
    "Horse Racing" => '<i class="far fa-horse-head" aria-hidden="true"></i>',
    "Swimming" => '<i class="far fa-swimmer" aria-hidden="true"></i>',
    "Chess" => '<i class="far fa-chess" aria-hidden="true"></i>',
    "ESports" => '<i class="far fa-gamepad-alt" aria-hidden="true"></i>',
    "Boxing" => '<i class="far fa-boxing-glove" aria-hidden="true"></i>',
    "Golf" => '<i class="far fa-golf-club" aria-hidden="true"></i>',
    "Dice" => '<i class="far fa-dice" aria-hidden="true"></i>',
    "Badminton" => '<i class="far fa-shuttlecock" aria-hidden="true"></i>',
];
